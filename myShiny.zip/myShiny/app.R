library(ggplot2)
library(shiny)
setwd("~/NanZHAO/Formation_BigData/Memoires/tmp/db/")
runApp("myShiny")
