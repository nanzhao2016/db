library(ggplot2)
library(shiny)
setwd("~/NanZHAO/Formation_BigData/Memoires/tmp/db")

# Ctrl+Shift+C
# shinyUI(
#   fluidPage(
#     titlePanel("Bike Sharing System Visualisation"),
# 
#     sidebarLayout(
#       sidebarPanel("Composant 1"),
#       
#       
# 
#       mainPanel(
#         h4("Boxplot of number of bicycles in country  ")
#       )
#     ),
#     sidebarLayout(
#       sidebarPanel("Composant 2"), mainPanel(
#         h4("hello ")
#       )
#       
#       
#     )
# 
#   )
# )


# shinyUI(
#   pageWithSidebar(
#     
#     # Application title
#     headerPanel("Hello Shiny!"),
#     
#     # Sidebar with a slider input
#     sidebarPanel(
#       sliderInput("obs",
#                   "Number of observations:",
#                   min = 0,
#                   max = 1000,
#                   value = 500)
#     ),
#     
#     sidebarPanel(postion="left",
#       sliderInput("obs",
#                   "Number of observations:",
#                   min = 0,
#                   max = 1000,
#                   value = 500)
#     )
#     # Show a plot of the generated distribution
#     
#   )
# )

shinyUI(
  fluidPage(
    
    titlePanel("Application Title"),
    
    navlistPanel(
      "Header",
      tabPanel("First", 
               sliderInput(inputId = "num",
                           label = "Choose a number",
                           value = 25, min=1, max=100),
               plotOutput(outputId = "hist")),
      
      tabPanel("Second",
               sidebarLayout(      
                 position = "right",
                 # Define the sidebar with one input
                 sidebarPanel(
                   selectInput("region", "Region:", 
                               choices=colnames(WorldPhones)),
                   hr(),
                   helpText("Data from AT&T (1961) The World's Telephones.")
                 ),
                 
                 # Create a spot for the barplot
                 mainPanel(
                   plotOutput("phonePlot")  
                 )
                 
               )
               ),
      tabPanel("Third"),
      fluid = TRUE,
      widths = c(2, 10)
    )
  )
)