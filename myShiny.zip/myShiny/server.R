library(shiny)
library(datasets)
setwd("~/NanZHAO/Formation_BigData/Memoires/tmp/db/")

shinyServer(function(input, output){
  
  output$hist <- renderPlot({
    title <- "Random normal values"
    hist(rnorm(input$num), main=title)
  })
  
  output$phonePlot <- renderPlot({
    
    # Render a barplot
    barplot(WorldPhones[,input$region]*1000, 
            main=input$region,
            ylab="Number of Telephones",
            xlab="Year")
  })
})