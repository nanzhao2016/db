library(ggplot2)
library(shiny)

histModule <- function(id, label = "Histograme") {
  
  ns = NS(id)
  
  tagList(
    
    sliderInput(ns("num"), label = "Choose a number",
                value = 25, min=1, max=100)
    
  )
  }
